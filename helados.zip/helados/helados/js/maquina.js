window.onload=function(){
	var powerButton = document.getElementById('power');	isOn = false;
	document.getElementById("buttons").style.display = "none";
	powerButton.addEventListener('click', function(event){

            if( isOn===true){
		         isOn = false;
				 event.target.parentElement.innerHTML = '<img src="img/power.png">';
				 document.getElementById("buttons").style.display = "none";
				 document.getElementById("conveyor_belt").innerHTML  = '<img src="img/conveyor.png">';
			}
			else{
			     isOn = true;
			     event.target.parentElement.innerHTML = '<img src="img/power_on.png">';
			     document.getElementById("buttons").style.display = "block";
				setTimeout(show, 1);
			}
	});
}

function helados(num){

switch (num) {
case 1:
document.getElementById("conveyor_belt").innerHTML  = '<img src="img/vanilla.jpg"> <br><br>	<img src="img/conveyor.png">';
break;

case 2:
   document.getElementById("conveyor_belt").innerHTML  = '<img src="img/chocolate.jpg"> <br><br>	<img src="img/conveyor.png">';
break;

case 3:
    document.getElementById("conveyor_belt").innerHTML  = '<img src="img/swirl.jpg"> <br><br>	<img src="img/conveyor.png">';
break; 

}
}
